package com.fedex.smartpost.spark.dao

class GSIPostalSummaryDAO {
  
}